
#include "graph.h"
#include <queue>
#include <limits>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

pair<int, vector<int>> dijkstra(Graph& g,int src,int dest,int mode, 
    string transportFilter, vector<int> blockedNodes) 
{
    map<int, int> dist;
    map<int, int> parent;

    for (int node : g.getAllNodes()) {
        dist[node] = INT_MAX;
        parent[node] = -1;
    }

    dist[src] = 0;

    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq;

    pq.push({0, src});

    while (!pq.empty()) {

        auto [currentDist, u] = pq.top();
        pq.pop();

        if (currentDist > dist[u]) continue;

        if (u == dest) break;

        for (const Edge& e : g.getNeighbors(u)) {

            int v = e.destination;

            // nodes
            bool blocked = false;
            for (int i = 0; i < blockedNodes.size(); i++) {
                if (blockedNodes[i] == v) {
                    blocked = true;
                    break;
                }
            }
            if (blocked) continue;

            // transport 
            if (transportFilter != "any" &&
                e.transportType != transportFilter)
                continue;

            
            int weight;

            if (mode == 1) weight = e.distance;  // shortest distance
            else if (mode == 2) weight = e.time;  // fastest time
            else weight = e.cost;                 // lowest cost

            
            if (dist[u] + weight < dist[v]) {
                dist[v] = dist[u] + weight;
                parent[v] = u;
                pq.push({dist[v], v});
            }
        }
    }

    // path
    vector<int> path;

    if (dist[dest] == INT_MAX)
        return {INT_MAX, path};

    for (int v = dest; v != -1; v = parent[v])
        path.push_back(v);

    reverse(path.begin(), path.end());

    return {dist[dest], path};
}