#include <iostream>
#include "graph.h"
#include <set>

using namespace std;


pair<int, vector<int>> dijkstra(Graph& g, int src, int dest,
    int mode, string transportFilter,vector<int> blockedNodes);

int main() {

    Graph g;
    g.loadFromFile("city.txt");

    int src, dest;
    int mode;
    string transport;
    cout<<endl;
    cout<<endl;
    cout<<endl;
    cout<<endl;
    cout << "CITY ROUTING SYSTEM\n";
    cout<< "====================\n";
    
    vector<int> nodes = g.getAllNodes();

    for (int i = 0; i < nodes.size(); i++) {
        int node = nodes[i];
        cout << "Neighbour of Station " << node << " is: ";
        vector<Edge> neighbors = g.getNeighbors(node);
        set<int> printed;

        for (int j = 0; j < neighbors.size(); j++) {
            int v = neighbors[j].destination;
            if (printed.find(v) == printed.end()) {
                cout << v;
                printed.insert(v);            
                cout << " ";
            }
            
        }   cout << endl;
    }
    cout << "Enter source: ";
    cin >> src;
    cout << "Enter destination: ";
    cin >> dest;
    cout << "Choose mode: \n";
    cout<<" 1 = Shortest distance\n 2 = Fastest route\n 3 = Cheapest route\n ";
    cin >> mode;
    cout << "Transport type (bus/metro/walk/any): ";
    cin >> transport;
    int n;
    cout << "How many blocked nodes? ";
    cin >> n;

    vector<int> blockedNodes;
    cout << "Enter blocked nodes:\n";
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        blockedNodes.push_back(x);
    }

    auto result = dijkstra(g, src, dest, mode, transport, blockedNodes);

    int cost = result.first;
    vector<int> path = result.second;

    if (cost == INT_MAX) {
        cout << "No path found\n";
        return 0;
    }

    cout << "\nThe Path is : ";
    for (int i = 0; i < path.size(); i++) {
        cout << path[i];
        if (i != path.size() - 1) cout << " -> ";
    }

    cout << "\nTotal Cost is: " << cost << endl;

    return 0;
}
