#include "graph.h"
#include <fstream>
#include <iostream>

using namespace std;

// Add an edge to the graph
void Graph::addEdge(int src, int dest, int distance, int time, int cost, string transportType) {
    adjList[src].push_back({dest, distance, time, cost, transportType});
    adjList[dest].push_back({src, distance, time, cost, transportType}); 
}

// Get all neighbors of a node
vector<Edge> Graph::getNeighbors(int node) {
    return adjList[node];
}

// Get all nodes in the graph
vector<int> Graph::getAllNodes() {
    vector<int> nodes;

    for (auto &pair : adjList) {
        nodes.push_back(pair.first);
    }

    return nodes;
}

// Load graph from file
void Graph::loadFromFile(string filename) {
    ifstream file(filename);

    if (!file) {
        cout << "Error opening file!" << endl;
        return;
    }

    int src, dest;
    int distance, time, cost;
    string transportType;

    while (file >> src >> dest >> distance >> time >> cost >> transportType) {
        addEdge(src, dest, distance, time, cost, transportType);
    }

    file.close();
}