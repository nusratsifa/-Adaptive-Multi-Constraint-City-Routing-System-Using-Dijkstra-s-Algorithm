#ifndef GRAPH_H
#define GRAPH_H

#include <vector>
#include <string>
#include <map>

using namespace std;

struct Edge {
    int destination;
    int distance;
    int time;
    int cost;
    string transportType;
};

class Graph {
private:
    map<int, vector<Edge>> adjList;

public:
    void addEdge(int src, int dest, int distance, int time, int cost, string transportType);
    vector<Edge> getNeighbors(int node);
    vector<int> getAllNodes();
    void loadFromFile(string filename);
};

#endif